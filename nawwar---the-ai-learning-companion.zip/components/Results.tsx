import React, { useEffect } from 'react';
import { Subject, Language, View, Question, UserProgress } from '../types';
import { UI_TEXT } from '../constants';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { PersonalizedRecommendations } from './PersonalizedRecommendations';

interface ResultsProps {
  subject: Subject;
  score: number;
  userAnswers: (number | null)[];
  questions: Question[];
  onRestart: () => void;
  language: Language;
  onUnlockAchievement: (achievementId: string) => void;
  userProgress: UserProgress; // Pass full progress for recommendations
}

const COLORS = ['#3b82f6', '#ef4444']; // Blue for correct, Red for incorrect

export const Results: React.FC<ResultsProps> = ({ subject, score, userAnswers, questions, onRestart, language, onUnlockAchievement, userProgress }) => {
  const text = UI_TEXT[language];
  const totalQuestions = questions.length;
  const incorrectAnswers = totalQuestions - score;

  useEffect(() => {
    // Unlock "First Quiz" achievement
    onUnlockAchievement('first_quiz');

    // Unlock "Perfect Score" achievement
    if (score === totalQuestions && totalQuestions > 0) {
        onUnlockAchievement('perfect_score');
    }
  }, [score, totalQuestions, onUnlockAchievement]);

  const chartData = [
    { name: text.correctAnswers, value: score },
    { name: 'Incorrect Answers', value: incorrectAnswers },
  ];

  return (
    <div className="p-4 md:p-8 space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-800">{text.quizResults}</h1>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-md flex flex-col md:flex-row items-center justify-center gap-8">
        <div style={{ width: '100%', maxWidth: '200px', height: '200px' }}>
            <ResponsiveContainer>
                <PieChart>
                    <Pie data={chartData} cx="50%" cy="50%" labelLine={false} outerRadius={80} fill="#8884d8" dataKey="value">
                        {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Pie>
                    <Tooltip />
                </PieChart>
            </ResponsiveContainer>
        </div>
        <div className="text-center md:text-start rtl:md:text-right">
            <p className="text-lg text-gray-600">{text.yourScore}</p>
            <p className="text-5xl font-bold text-blue-500">
                {score} <span className="text-2xl text-gray-500">/ {totalQuestions}</span>
            </p>
             {totalQuestions > 0 && <p className="mt-2 text-xl font-semibold">
                {((score / totalQuestions) * 100).toFixed(0)}%
            </p>}
        </div>
      </div>
      
      <PersonalizedRecommendations userProgress={userProgress} language={language} />

      <div className="bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-xl font-bold text-gray-700 mb-4">Review Answers</h2>
        <div className="space-y-6">
          {questions.map((question, index) => {
            const userAnswer = userAnswers[index];
            const isCorrect = userAnswer === question.correctAnswerIndex;
            return (
              <div key={question.id} className="border-b pb-4 last:border-b-0">
                <p className="font-semibold text-gray-800 mb-2">{index + 1}. {question.text}</p>
                <div className="space-y-1">
                  {question.options.map((option, optIndex) => {
                    let optionClass = 'text-gray-600';
                    if (optIndex === question.correctAnswerIndex) {
                      optionClass = 'text-green-600 font-bold';
                    } else if (optIndex === userAnswer) {
                      optionClass = 'text-red-600 line-through';
                    }
                    return <p key={optIndex} className={optionClass}>- {option}</p>
                  })}
                </div>
                <div className={`mt-3 p-3 border rounded-lg ${isCorrect ? 'bg-green-50 border-green-200' : 'bg-yellow-50 border-yellow-200'}`}>
                    <p className={`font-bold ${isCorrect ? 'text-green-800' : 'text-yellow-800'}`}>{text.explanation}</p>
                    <p className={`${isCorrect ? 'text-green-700' : 'text-yellow-700'}`}>{question.explanation}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
      <button
        onClick={onRestart}
        className="w-full bg-blue-500 text-white font-bold py-4 px-6 rounded-lg hover:bg-blue-600 transition-colors duration-300 shadow-lg"
      >
        {text.backToDashboard}
      </button>
    </div>
  );
};