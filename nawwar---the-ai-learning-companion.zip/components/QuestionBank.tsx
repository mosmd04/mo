import React, { useState, useMemo } from 'react';
import { Language, Difficulty } from '../types';
import { UI_TEXT, SUBJECTS } from '../constants';

export const QuestionBank: React.FC<{ language: Language }> = ({ language }) => {
  const text = UI_TEXT[language];
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('all');
  const [selectedChapter, setSelectedChapter] = useState('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty>('all');
  
  const allQuestions = useMemo(() => SUBJECTS.flatMap(subject => 
    subject.questions.map(q => ({ ...q, subjectName: subject.name[language], subjectId: subject.id, chapterName: subject.chapters.find(c => c.id === q.chapterId)?.name[language] }))
  ), [language]);

  const filteredQuestions = useMemo(() => {
    return allQuestions.filter(q => {
      const searchMatch = q.text.toLowerCase().includes(searchTerm.toLowerCase());
      const subjectMatch = selectedSubject === 'all' || q.subjectId === selectedSubject;
      const chapterMatch = selectedChapter === 'all' || q.chapterId === selectedChapter;
      const difficultyMatch = selectedDifficulty === 'all' || q.difficulty === selectedDifficulty;
      return searchMatch && subjectMatch && chapterMatch && difficultyMatch;
    });
  }, [allQuestions, searchTerm, selectedSubject, selectedChapter, selectedDifficulty]);

  const availableChapters = useMemo(() => {
    if (selectedSubject === 'all') {
      return [];
    }
    return SUBJECTS.find(s => s.id === selectedSubject)?.chapters || [];
  }, [selectedSubject]);

  return (
    <div className="p-4 md:p-8 space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">{text.questionBank}</h1>
      
      <div className="bg-white p-6 rounded-xl shadow-md space-y-4">
        <input
            type="text"
            placeholder={text.searchQuestions}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <select value={selectedSubject} onChange={e => { setSelectedSubject(e.target.value); setSelectedChapter('all'); }} className="p-3 border border-gray-300 rounded-lg">
                <option value="all">{text.allSubjects}</option>
                {SUBJECTS.map(s => <option key={s.id} value={s.id}>{s.name[language]}</option>)}
            </select>
            <select value={selectedChapter} onChange={e => setSelectedChapter(e.target.value)} className="p-3 border border-gray-300 rounded-lg" disabled={selectedSubject === 'all'}>
                <option value="all">{text.allChapters}</option>
                {availableChapters.map(c => <option key={c.id} value={c.id}>{c.name[language]}</option>)}
            </select>
            <select value={selectedDifficulty} onChange={e => setSelectedDifficulty(e.target.value as Difficulty)} className="p-3 border border-gray-300 rounded-lg">
                <option value="all">{text.allDifficulties}</option>
                <option value="easy">{text.easy}</option>
                <option value="medium">{text.medium}</option>
                <option value="hard">{text.hard}</option>
            </select>
        </div>
      </div>

      <div className="space-y-4">
        {filteredQuestions.length > 0 ? (
          filteredQuestions.map(q => (
            <div key={q.id + q.subjectId} className="bg-white p-5 rounded-xl shadow-md">
              <p className="font-semibold text-gray-800">{q.text}</p>
              <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">{q.subjectName}</span>
                <span className="bg-gray-100 text-gray-800 px-2 py-1 rounded-full">{q.chapterName}</span>
                <span className={`capitalize bg-${q.difficulty === 'easy' ? 'green' : q.difficulty === 'medium' ? 'yellow' : 'red'}-100 text-${q.difficulty === 'easy' ? 'green' : q.difficulty === 'medium' ? 'yellow' : 'red'}-800 px-2 py-1 rounded-full`}>{q.difficulty}</span>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-500">{text.noQuestionsFound}</p>
          </div>
        )}
      </div>
    </div>
  );
};