
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const systemInstruction = `أنت مدرس افتراضي متخصص وودود اسمه "نوّر". هدفك هو مساعدة الطلاب على فهم المفاهيم الصعبة بأسلوب بسيط ومشجع. 
اشرح الإجابات بالتفصيل وقدم أمثلة واضحة. استخدم اللغة العربية الفصحى المبسطة. كن صبوراً وإيجابياً دائماً. إذا سألك الطالب باللغة الإنجليزية، أجب باللغة الإنجليزية.`;

export const getTutorResponseStream = async (prompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction,
      },
      history: history,
    });
    
    const result = await chat.sendMessageStream({ message: prompt });
    return result;
  } catch (error) {
    console.error("Error getting response from Gemini:", error);
    throw error;
  }
};
