import React, { useState, useCallback, useEffect } from 'react';
import { View, Language, Subject as SubjectType, Question } from './types';
import { Dashboard } from './components/Dashboard';
import { PracticeSession } from './components/PracticeSession';
import { Results } from './components/Results';
import { AITutor } from './components/AITutor';
import { Stats } from './components/Stats';
import { Leaderboard } from './components/Leaderboard';
import { Achievements } from './components/Achievements';
import { QuestionBank } from './components/QuestionBank';
import { Forum } from './components/Forum';
import { Challenge } from './components/Challenge';
import { ParentDashboard } from './components/ParentDashboard';
import { DashboardIcon, PracticeIcon, TutorIcon, ChartBarIcon, TrophyIcon, SparklesIcon, QuestionBankIcon, ForumIcon, ChallengeIcon, ParentIcon } from './components/icons';
import { SUBJECTS, UI_TEXT, MOCK_USER_PROGRESS } from './constants';

const App: React.FC = () => {
    const [view, setView] = useState<View>('dashboard');
    const [language, setLanguage] = useState<Language>('ar');
    const [selectedSubject, setSelectedSubject] = useState<SubjectType | null>(null);
    const [quizResult, setQuizResult] =useState<{ score: number; userAnswers: (number | null)[]; questions: Question[] } | null>(null);
    const [userProgress, setUserProgress] = useState(MOCK_USER_PROGRESS);
    const [unlockedAchievements, setUnlockedAchievements] = useState<Set<string>>(new Set(['first_quiz'])); // Pre-unlock one for demo

    useEffect(() => {
        document.documentElement.lang = language;
        document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    }, [language]);

    const handleSelectSubject = useCallback((subjectId: string) => {
        const subject = SUBJECTS.find(s => s.id === subjectId);
        if (subject) {
            setSelectedSubject(subject);
            setView('practice');
        }
    }, []);

    const handleFinishQuiz = useCallback((score: number, userAnswers: (number | null)[], questions: Question[]) => {
        setQuizResult({ score, userAnswers, questions });
        // In a real app, you would update userProgress based on quiz results.
        // For this prototype, we'll just show the results.
        setUserProgress(prev => ({
            ...prev,
            totalSessions: prev.totalSessions + 1,
            totalQuestions: prev.totalQuestions + questions.length,
            overallCorrect: prev.overallCorrect + score,
            history: [...prev.history, { score, totalQuestions: questions.length, date: new Date().toISOString() }],
            // Add subject-specific progress update logic here if needed
        }));
        setView('results');
    }, []);
    
    const handleRestart = useCallback(() => {
        setView('dashboard');
        setSelectedSubject(null);
        setQuizResult(null);
    }, []);

    const handleUnlockAchievement = useCallback((achievementId: string) => {
        setUnlockedAchievements(prev => new Set(prev).add(achievementId));
    }, []);

    const toggleLanguage = () => {
        setLanguage(prev => (prev === 'ar' ? 'en' : 'ar'));
    };

    const text = UI_TEXT[language];

    const renderView = () => {
        switch (view) {
            case 'practice':
                if (selectedSubject) {
                    return <PracticeSession subject={selectedSubject} onFinish={handleFinishQuiz} language={language} />;
                }
                return null;
            case 'results':
                if (selectedSubject && quizResult) {
                    return <Results subject={selectedSubject} score={quizResult.score} userAnswers={quizResult.userAnswers} questions={quizResult.questions} onRestart={handleRestart} language={language} onUnlockAchievement={handleUnlockAchievement} userProgress={userProgress} />;
                }
                return null;
            case 'tutor':
                return <AITutor language={language} />;
            case 'stats':
                return <Stats language={language} userProgress={userProgress} />;
            case 'leaderboard':
                return <Leaderboard language={language} />;
            case 'achievements':
                return <Achievements language={language} unlockedAchievements={unlockedAchievements} />;
            case 'questionBank':
                return <QuestionBank language={language} />;
            case 'forum':
                return <Forum language={language} />;
            case 'challenge':
                return <Challenge language={language} />;
            case 'parentDashboard':
                return <ParentDashboard language={language} userProgress={userProgress} />;
            case 'dashboard':
            default:
                return <Dashboard onSelectSubject={handleSelectSubject} language={language} setView={setView} userProgress={userProgress} />;
        }
    };

    const navItems = [
        { id: 'dashboard', label: text.dashboard, icon: DashboardIcon, view: 'dashboard' as View },
        { id: 'practice', label: text.practice, icon: PracticeIcon, view: 'practice' as View, action: () => handleSelectSubject('math') }, // Default to math for direct click
        { id: 'questionBank', label: text.questionBank, icon: QuestionBankIcon, view: 'questionBank' as View },
        { id: 'stats', label: text.stats, icon: ChartBarIcon, view: 'stats' as View },
        { id: 'leaderboard', label: text.leaderboard, icon: TrophyIcon, view: 'leaderboard' as View },
        { id: 'achievements', label: text.achievements, icon: SparklesIcon, view: 'achievements' as View },
        { id: 'tutor', label: text.tutor, icon: TutorIcon, view: 'tutor' as View },
        { id: 'forum', label: text.forum, icon: ForumIcon, view: 'forum' as View },
        { id: 'challenge', label: text.challenge, icon: ChallengeIcon, view: 'challenge' as View },
        { id: 'parentDashboard', label: text.parentDashboard, icon: ParentIcon, view: 'parentDashboard' as View },
    ];
    
    return (
        <div className={`flex h-screen bg-slate-100 font-sans ${language === 'ar' ? 'rtl' : 'ltr'}`}>
             <nav className="w-20 lg:w-64 bg-white shadow-lg flex flex-col justify-between">
                <div>
                    <div className="flex items-center justify-center lg:justify-start lg:px-6 h-20 border-b">
                        <span className="text-2xl font-bold text-blue-600">ن</span>
                        <span className="hidden lg:inline font-bold text-xl text-gray-800 mx-2">{text.appName}</span>
                    </div>
                    <ul className="overflow-y-auto" style={{ height: 'calc(100vh - 160px)' }}>
                        {navItems.map(item => (
                             <li key={item.id} className="px-2 lg:px-4 py-2">
                                <button
                                    onClick={() => item.action ? item.action() : setView(item.view)}
                                    className={`w-full flex items-center justify-center lg:justify-start p-3 rounded-lg transition-colors ${
                                        view === item.view ? 'bg-blue-500 text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'
                                    }`}
                                >
                                    <item.icon className="w-6 h-6" />
                                    <span className="hidden lg:inline mx-4 font-semibold">{item.label}</span>
                                </button>
                            </li>
                        ))}
                    </ul>
                </div>
                <div className="p-4 border-t">
                    <button onClick={toggleLanguage} className="w-full text-center p-3 rounded-lg text-gray-600 hover:bg-gray-100 font-semibold transition-colors">
                        {language === 'ar' ? 'English' : 'العربية'}
                    </button>
                </div>
             </nav>
            <main className="flex-1 flex flex-col overflow-hidden">
                <header className="h-20 bg-white border-b flex items-center justify-between px-8">
                    <h1 className="text-xl font-semibold text-gray-800">
                      {navItems.find(item => item.view === view)?.label || text.dashboard}
                    </h1>
                     <div className="flex items-center">
                        <img src="https://i.pravatar.cc/40?u=student" alt="User Avatar" className="w-10 h-10 rounded-full" />
                    </div>
                </header>
                <div className="flex-1 overflow-y-auto">
                    {renderView()}
                </div>
            </main>
        </div>
    );
};

export default App;