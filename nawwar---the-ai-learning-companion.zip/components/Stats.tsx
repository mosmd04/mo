
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { UserProgress, Language, SubjectStats } from '../types';
import { UI_TEXT, SUBJECTS } from '../constants';

interface StatsProps {
  userProgress: UserProgress;
  language: Language;
}

export const Stats: React.FC<StatsProps> = ({ userProgress, language }) => {
  const text = UI_TEXT[language];

  const overallAccuracy = userProgress.totalQuestions > 0
    ? ((userProgress.overallCorrect / userProgress.totalQuestions) * 100).toFixed(0)
    : 0;

  // Fix: Explicitly type `stats` as `SubjectStats` to resolve TypeScript inference issue where it's treated as `unknown`.
  const subjectAccuracyData = Object.entries(userProgress.bySubject).map(([subjectId, stats]: [string, SubjectStats]) => {
    const subject = SUBJECTS.find(s => s.id === subjectId);
    return {
      name: subject?.name[language] || 'Unknown',
      [text.overallAccuracy]: stats.total > 0 ? (stats.correct / stats.total) * 100 : 0,
    };
  });

  const StatCard: React.FC<{ title: string, value: string | number }> = ({ title, value }) => (
    <div className="bg-white p-6 rounded-xl shadow-md text-center">
        <p className="text-lg text-gray-500">{title}</p>
        <p className="text-4xl font-bold text-blue-500 mt-2">{value}</p>
    </div>
  );

  return (
    <div className="p-4 md:p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">{text.performanceStats}</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title={text.totalSessions} value={userProgress.totalSessions} />
        <StatCard title={text.questionsAnswered} value={userProgress.totalQuestions} />
        <StatCard title={text.overallAccuracy} value={`${overallAccuracy}%`} />
      </div>

      <div className="bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-xl font-bold text-gray-700 mb-4">{text.accuracyBySubject}</h2>
        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer>
            <BarChart data={subjectAccuracyData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis unit="%" domain={[0, 100]} />
              <Tooltip />
              <Legend />
              <Bar dataKey={text.overallAccuracy} fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
