import React from 'react';
import { Language } from '../types';
import { UI_TEXT, LEADERBOARD_DATA } from '../constants';

export const Challenge: React.FC<{ language: Language }> = ({ language }) => {
  const text = UI_TEXT[language];
  
  // Mock data for online friends, excluding the current user
  const onlineFriends = LEADERBOARD_DATA.filter(u => !u.isCurrentUser).slice(0, 4);

  return (
    <div className="p-4 md:p-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">{text.challengeAFriend}</h1>
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {onlineFriends.map(friend => (
            <div key={friend.rank} className="border rounded-lg p-4 text-center flex flex-col items-center">
              <img 
                src={`https://i.pravatar.cc/80?u=${friend.name}`} 
                alt={friend.name}
                className="w-20 h-20 rounded-full mb-3"
              />
              <p className="font-bold text-lg">{friend.name}</p>
              <div className="flex items-center text-sm text-green-600 my-2">
                <span className="h-2 w-2 bg-green-500 rounded-full me-2"></span>
                {text.online}
              </div>
              <button className="mt-auto w-full bg-green-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-green-600 transition-colors">
                {text.challengeNow}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};