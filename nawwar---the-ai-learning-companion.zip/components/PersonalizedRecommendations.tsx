import React, { useMemo } from 'react';
import { UserProgress, Language, SubjectStats } from '../types';
import { UI_TEXT, SUBJECTS } from '../constants';
import { LightbulbIcon } from './icons';

interface PersonalizedRecommendationsProps {
  userProgress: UserProgress;
  language: Language;
}

export const PersonalizedRecommendations: React.FC<PersonalizedRecommendationsProps> = ({ userProgress, language }) => {
  const text = UI_TEXT[language];

  const recommendation = useMemo(() => {
    const performance = Object.entries(userProgress.bySubject).map(([subjectId, stats]: [string, SubjectStats]) => {
      const accuracy = stats.total > 0 ? (stats.correct / stats.total) * 100 : 101; // 101 to ignore subjects with no data
      return { subjectId, accuracy };
    }).sort((a, b) => a.accuracy - b.accuracy);

    if (performance.length === 0 || performance[0].accuracy > 75) {
      return null; // No recommendations needed if all subjects are above 75%
    }
    
    const weakestSubjectId = performance[0].subjectId;
    const weakestSubject = SUBJECTS.find(s => s.id === weakestSubjectId);

    if (!weakestSubject) return null;

    if (language === 'ar') {
        return `يبدو أنك تواجه بعض الصعوبات في ${weakestSubject.name.ar}. لم لا تجرب حل بعض الأسئلة في فصل "${weakestSubject.chapters[0]?.name.ar || ''}" لتقوية فهمك؟`;
    }
    return `It looks like you're having some trouble with ${weakestSubject.name.en}. Why not try some practice questions from the "${weakestSubject.chapters[0]?.name.en || ''}" chapter to strengthen your understanding?`;

  }, [userProgress, language]);

  if (!recommendation) {
    return null;
  }

  return (
    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg shadow-md">
        <div className="flex">
            <div className="py-1">
                <LightbulbIcon className="w-6 h-6 text-yellow-500" />
            </div>
            <div className="ms-3">
                <h3 className="font-bold text-yellow-800">{text.personalizedRecommendations}</h3>
                <p className="text-sm text-yellow-700 mt-1">{recommendation}</p>
            </div>
        </div>
    </div>
  );
};