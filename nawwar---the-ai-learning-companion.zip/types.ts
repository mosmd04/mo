import React from 'react';

export interface Chapter {
  id: string;
  name: { [key: string]: string };
}

export interface Question {
  id: number;
  chapterId: string;
  text: string;
  options: string[];
  correctAnswerIndex: number;
  difficulty: 'easy' | 'medium' | 'hard';
  explanation: string;
}

export interface Subject {
  id: string;
  name: { [key: string]: string };
  icon: React.ComponentType<{ className?: string }>;
  chapters: Chapter[];
  questions: Question[];
}

export interface ExamResult {
  score: number;
  totalQuestions: number;
  date: string;
}

export interface Achievement {
  id: string;
  name: { [key: string]: string };
  description: { [key: string]: string };
  icon: React.ComponentType<{ className?: string }>;
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  points: number;
  isCurrentUser?: boolean;
}

export interface SubjectStats {
  correct: number;
  total: number;
}

export interface UserProgress {
  totalSessions: number;
  totalQuestions: number;
  overallCorrect: number;
  bySubject: { [subjectId: string]: SubjectStats };
  history: ExamResult[];
}

export interface ForumReply {
    id: number;
    author: string;
    avatar: string;
    content: string;
    timestamp: string;
}

export interface ForumPost {
    id: number;
    author: string;
    avatar: string;
    title: string;
    content: string;
    repliesCount: number;
    timestamp: string;
}


export type View = 'dashboard' | 'practice' | 'results' | 'tutor' | 'stats' | 'leaderboard' | 'achievements' | 'questionBank' | 'forum' | 'challenge' | 'parentDashboard';

export type Language = 'ar' | 'en';

export type Difficulty = 'easy' | 'medium' | 'hard' | 'all';