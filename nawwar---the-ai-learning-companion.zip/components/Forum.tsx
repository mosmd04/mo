import React, { useState } from 'react';
import { Language } from '../types';
import { UI_TEXT, FORUM_POSTS } from '../constants';

export const Forum: React.FC<{ language: Language }> = ({ language }) => {
  const text = UI_TEXT[language];
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="p-4 md:p-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">{text.forum}</h1>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-blue-500 text-white font-bold py-2 px-5 rounded-lg hover:bg-blue-600 transition-colors"
        >
          {text.newPost}
        </button>
      </div>
      
      <div className="space-y-4">
        {FORUM_POSTS.map(post => (
          <div key={post.id} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
            <div className="flex items-start">
              <img src={post.avatar} alt={post.author} className="w-12 h-12 rounded-full"/>
              <div className="ms-4 flex-1">
                <h2 className="font-bold text-lg text-gray-800">{post.title}</h2>
                <p className="text-sm text-gray-500">
                  {post.author} - <span className="text-xs">{post.timestamp}</span>
                </p>
                <p className="mt-2 text-gray-600">{post.content}</p>
                <div className="mt-3 text-sm font-semibold text-blue-600">
                  {post.repliesCount} {text.replies}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-lg p-6">
            <h2 className="text-xl font-bold mb-4">{text.newPost}</h2>
            <form>
              <input 
                type="text"
                placeholder={text.postTitle}
                className="w-full p-3 border border-gray-300 rounded-lg mb-4"
              />
              <textarea
                placeholder={text.postContent}
                rows={5}
                className="w-full p-3 border border-gray-300 rounded-lg mb-4"
              ></textarea>
              <div className="flex justify-end gap-3">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 bg-gray-200 rounded-lg">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded-lg">{text.addPost}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};