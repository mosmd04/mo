import React, { useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Language, UserProgress, SubjectStats } from '../types';
import { UI_TEXT, SUBJECTS } from '../constants';

interface ParentDashboardProps {
  userProgress: UserProgress;
  language: Language;
}

const StatCard: React.FC<{ title: string, value: string | number }> = ({ title, value }) => (
    <div className="bg-white p-6 rounded-xl shadow-md text-center">
        <p className="text-lg text-gray-500">{title}</p>
        <p className="text-4xl font-bold text-blue-500 mt-2">{value}</p>
    </div>
);

const StrengthsAndWeaknesses: React.FC<{ userProgress: UserProgress, language: Language }> = ({ userProgress, language }) => {
    const text = UI_TEXT[language];

    const performance = useMemo(() => {
        return Object.entries(userProgress.bySubject).map(([subjectId, stats]: [string, SubjectStats]) => {
            const subject = SUBJECTS.find(s => s.id === subjectId);
            const accuracy = stats.total > 0 ? (stats.correct / stats.total) * 100 : 0;
            return {
                id: subjectId,
                name: subject?.name[language] || '',
                icon: subject?.icon,
                accuracy: accuracy,
            };
        }).sort((a, b) => a.accuracy - b.accuracy);
    }, [userProgress, language]);

    if (performance.length < 2) return null;

    const weakness = performance[0];
    const strength = performance[performance.length - 1];

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-bold text-gray-700 mb-4">{text.strengthsAndWeaknesses}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-green-50 p-4 rounded-lg">
                    <h3 className="font-bold text-green-800">{text.strength}</h3>
                    <div className="flex items-center mt-2">
                        {strength.icon && <strength.icon className="w-8 h-8 text-green-600" />}
                        <span className="ms-3 font-semibold text-gray-700">{strength.name}</span>
                        <span className="ms-auto font-bold text-green-600">{strength.accuracy.toFixed(0)}%</span>
                    </div>
                </div>
                <div className="bg-red-50 p-4 rounded-lg">
                    <h3 className="font-bold text-red-800">{text.weakness}</h3>
                    <div className="flex items-center mt-2">
                         {weakness.icon && <weakness.icon className="w-8 h-8 text-red-600" />}
                        <span className="ms-3 font-semibold text-gray-700">{weakness.name}</span>
                        <span className="ms-auto font-bold text-red-600">{weakness.accuracy.toFixed(0)}%</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const ParentDashboard: React.FC<ParentDashboardProps> = ({ userProgress, language }) => {
  const text = UI_TEXT[language];

  const overallAccuracy = userProgress.totalQuestions > 0
    ? ((userProgress.overallCorrect / userProgress.totalQuestions) * 100).toFixed(0)
    : 0;

  const progressData = userProgress.history.map(p => ({
    name: new Date(p.date).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', { month: 'short', day: 'numeric' }),
    [text.progress]: (p.score / p.totalQuestions) * 100
  }));

  return (
    <div className="p-4 md:p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">{text.welcomeParent}</h1>
        <p className="text-gray-500 mt-1">{text.studentProgress}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title={text.totalSessions} value={userProgress.totalSessions} />
        <StatCard title={text.questionsAnswered} value={userProgress.totalQuestions} />
        <StatCard title={text.overallAccuracy} value={`${overallAccuracy}%`} />
      </div>

      <StrengthsAndWeaknesses userProgress={userProgress} language={language} />

      <div className="bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-xl font-bold text-gray-700 mb-4">{text.progressOverTime}</h2>
        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer>
            <LineChart data={progressData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis unit="%" domain={[0, 100]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey={text.progress} stroke="#3b82f6" strokeWidth={2} activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};