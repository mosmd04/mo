import React, { useMemo, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Subject, Language, View, UserProgress, SubjectStats } from '../types';
import { SUBJECTS, UI_TEXT } from '../constants';
import { PersonalizedRecommendations } from './PersonalizedRecommendations';
import { PdfIcon } from './icons';

interface DashboardProps {
  onSelectSubject: (subjectId: string) => void;
  language: Language;
  setView: (view: View) => void;
  userProgress: UserProgress;
}

const StrengthsAndWeaknesses: React.FC<{ userProgress: UserProgress, language: Language }> = ({ userProgress, language }) => {
    const text = UI_TEXT[language];

    const performance = useMemo(() => {
        return Object.entries(userProgress.bySubject).map(([subjectId, stats]: [string, SubjectStats]) => {
            const subject = SUBJECTS.find(s => s.id === subjectId);
            const accuracy = stats.total > 0 ? (stats.correct / stats.total) * 100 : 0;
            return {
                id: subjectId,
                name: subject?.name[language] || '',
                icon: subject?.icon,
                accuracy: accuracy,
            };
        }).sort((a, b) => a.accuracy - b.accuracy);
    }, [userProgress, language]);

    if (performance.length < 2) {
        return null;
    }

    const weakness = performance[0];
    const strength = performance[performance.length - 1];

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-bold text-gray-700 mb-4">{text.strengthsAndWeaknesses}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-green-50 p-4 rounded-lg">
                    <h3 className="font-bold text-green-800">{text.strength}</h3>
                    <div className="flex items-center mt-2">
                        {strength.icon && <strength.icon className="w-8 h-8 text-green-600" />}
                        <span className="ms-3 font-semibold text-gray-700">{strength.name}</span>
                        <span className="ms-auto font-bold text-green-600">{strength.accuracy.toFixed(0)}%</span>
                    </div>
                </div>
                <div className="bg-red-50 p-4 rounded-lg">
                    <h3 className="font-bold text-red-800">{text.weakness}</h3>
                    <div className="flex items-center mt-2">
                         {weakness.icon && <weakness.icon className="w-8 h-8 text-red-600" />}
                        <span className="ms-3 font-semibold text-gray-700">{weakness.name}</span>
                        <span className="ms-auto font-bold text-red-600">{weakness.accuracy.toFixed(0)}%</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

const SmartSummaries: React.FC<{ language: Language }> = ({ language }) => {
    const text = UI_TEXT[language];
    const [isGenerating, setIsGenerating] = useState(false);

    const handleGenerate = () => {
        setIsGenerating(true);
        // Simulate PDF generation
        setTimeout(() => {
            setIsGenerating(false);
            alert(text.generatingPDF);
        }, 1500);
    };

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-bold text-gray-700 mb-4">{text.smartSummaries}</h2>
            <div className="flex flex-col sm:flex-row items-center gap-4">
                <select className="w-full sm:w-1/2 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    {SUBJECTS.map(s => (
                        <optgroup key={s.id} label={s.name[language]}>
                            {s.chapters.map(c => (
                                <option key={c.id} value={c.id}>
                                    {c.name[language]}
                                </option>
                            ))}
                        </optgroup>
                    ))}
                </select>
                <button
                    onClick={handleGenerate}
                    disabled={isGenerating}
                    className="w-full sm:w-1/2 flex items-center justify-center gap-2 p-3 bg-blue-500 text-white font-bold rounded-lg hover:bg-blue-600 transition-colors disabled:bg-blue-300"
                >
                    <PdfIcon className="w-6 h-6" />
                    {isGenerating ? text.generatingPDF : text.generatePDF}
                </button>
            </div>
        </div>
    );
};


export const Dashboard: React.FC<DashboardProps> = ({ onSelectSubject, language, setView, userProgress }) => {
  const text = UI_TEXT[language];

  const progressData = userProgress.history.map(p => ({
    name: new Date(p.date).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', { month: 'short', day: 'numeric' }),
    [text.progress]: (p.score / p.totalQuestions) * 100
  }));

  return (
    <div className="p-4 md:p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">{text.welcome}</h1>
        <p className="text-gray-500 mt-1">{text.startPractice}</p>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-xl font-bold text-gray-700 mb-4">{text.chooseSubject}</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {SUBJECTS.map((subject) => (
            <button
              key={subject.id}
              onClick={() => onSelectSubject(subject.id)}
              className="group flex flex-col items-center justify-center p-4 bg-slate-50 hover:bg-blue-500 rounded-lg transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg text-center"
            >
              <subject.icon className="w-12 h-12 text-blue-500 group-hover:text-white transition-colors" />
              <span className="mt-2 font-semibold text-gray-700 group-hover:text-white transition-colors">{subject.name[language]}</span>
            </button>
          ))}
        </div>
      </div>
      
      <PersonalizedRecommendations userProgress={userProgress} language={language} />

      <StrengthsAndWeaknesses userProgress={userProgress} language={language} />

      <SmartSummaries language={language} />

      <div className="bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-xl font-bold text-gray-700 mb-4">{text.progressOverTime}</h2>
        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer>
            <LineChart
              data={progressData}
              margin={{ top: 5, right: 20, left: -10, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis unit="%" domain={[0, 100]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey={text.progress} stroke="#3b82f6" strokeWidth={2} activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};