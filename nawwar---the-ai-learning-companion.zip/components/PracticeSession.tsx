import React, { useState, useMemo } from 'react';
import { Subject, Question, Language, Difficulty } from '../types';
import { UI_TEXT } from '../constants';

interface PracticeSessionProps {
  subject: Subject;
  onFinish: (score: number, userAnswers: (number | null)[], questions: Question[]) => void;
  language: Language;
}

type Step = 'chapter_selection' | 'difficulty_selection' | 'in_progress';

export const PracticeSession: React.FC<PracticeSessionProps> = ({ subject, onFinish, language }) => {
  const [step, setStep] = useState<Step>('chapter_selection');
  const [selectedChapters, setSelectedChapters] = useState<Set<string>>(new Set());
  const [difficulty, setDifficulty] = useState<Difficulty>('all');
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>([]);
  const [showError, setShowError] = useState(false);
  
  const text = UI_TEXT[language];

  const filteredQuestions = useMemo(() => {
      if (selectedChapters.size === 0) return [];
      
      const chapterQuestions = subject.questions.filter(q => selectedChapters.has(q.chapterId));
      
      if (difficulty === 'all') return chapterQuestions;
      return chapterQuestions.filter(q => q.difficulty === difficulty);
  }, [subject.questions, difficulty, selectedChapters]);

  const handleToggleChapter = (chapterId: string) => {
      setSelectedChapters(prev => {
          const newSet = new Set(prev);
          if (newSet.has(chapterId)) {
              newSet.delete(chapterId);
          } else {
              newSet.add(chapterId);
          }
          return newSet;
      });
  };
  
  const handleSelectAllChapters = () => {
      if (selectedChapters.size === subject.chapters.length) {
          setSelectedChapters(new Set());
      } else {
          setSelectedChapters(new Set(subject.chapters.map(c => c.id)));
      }
  };

  const handleStartDifficultySelection = () => {
      if (selectedChapters.size > 0) {
          setStep('difficulty_selection');
      }
  };
  
  const handleSelectDifficulty = (level: Difficulty) => {
    setDifficulty(level);
    setUserAnswers(Array(filteredQuestions.length).fill(null)); // This needs to be called after questions are filtered
    setStep('in_progress');
  };
  
  // This effect recalculates userAnswers array size when filteredQuestions change
  React.useEffect(() => {
    setUserAnswers(Array(filteredQuestions.length).fill(null));
  }, [filteredQuestions.length]);


  const handleSelectAnswer = (index: number) => {
    setSelectedAnswer(index);
    setShowError(false);
    const newAnswers = [...userAnswers];
    newAnswers[currentQuestionIndex] = index;
    setUserAnswers(newAnswers);
  };

  const handleNext = () => {
    if (selectedAnswer === null) {
      setShowError(true);
      return;
    }

    if (currentQuestionIndex < filteredQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(userAnswers[currentQuestionIndex + 1]);
    } else {
      const score = userAnswers.reduce((acc, answer, index) => {
        return answer === filteredQuestions[index].correctAnswerIndex ? acc + 1 : acc;
      }, 0);
      onFinish(score, userAnswers, filteredQuestions);
    }
  };

  if (step === 'chapter_selection') {
      return (
        <div className="p-4 md:p-8 flex flex-col items-center justify-center h-full">
            <div className="bg-white p-8 rounded-xl shadow-md text-center w-full max-w-lg">
                <h2 className="text-2xl font-bold text-gray-800 mb-2">{subject.name[language]}</h2>
                <p className="text-gray-600 mb-6">{text.chooseChapters}</p>
                <div className="space-y-3 max-h-64 overflow-y-auto mb-4 text-start">
                    <button
                        onClick={handleSelectAllChapters}
                        className="w-full flex items-center p-3 border-2 rounded-lg bg-slate-50 font-semibold"
                    >
                        <input
                            type="checkbox"
                            className="form-checkbox h-5 w-5 text-blue-600 rounded"
                            checked={selectedChapters.size === subject.chapters.length}
                            readOnly
                        />
                        <span className="ms-3">{text.selectAll}</span>
                    </button>
                    {subject.chapters.map(chapter => (
                        <div key={chapter.id} className="flex items-center p-3 border-2 rounded-lg hover:bg-gray-50 cursor-pointer" onClick={() => handleToggleChapter(chapter.id)}>
                             <input
                                type="checkbox"
                                className="form-checkbox h-5 w-5 text-blue-600 rounded"
                                checked={selectedChapters.has(chapter.id)}
                                readOnly
                            />
                            <span className="ms-3">{chapter.name[language]}</span>
                        </div>
                    ))}
                </div>
                <button
                    onClick={handleStartDifficultySelection}
                    disabled={selectedChapters.size === 0}
                    className="w-full bg-blue-500 text-white font-bold py-4 px-6 rounded-lg hover:bg-blue-600 transition-colors duration-300 shadow-lg disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                    {text.nextQuestion}
                </button>
            </div>
        </div>
      );
  }

  if (step === 'difficulty_selection') {
    return (
      <div className="p-4 md:p-8 flex flex-col items-center justify-center h-full">
        <div className="bg-white p-8 rounded-xl shadow-md text-center w-full max-w-md">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">{text.chooseDifficulty}</h2>
          <div className="space-y-4">
            {(['easy', 'medium', 'hard', 'all'] as Difficulty[]).map(level => (
              <button
                key={level}
                onClick={() => handleSelectDifficulty(level)}
                className="w-full bg-blue-500 text-white font-bold py-4 px-6 rounded-lg hover:bg-blue-600 transition-colors duration-300 shadow-lg capitalize"
              >
                {text[level]}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const currentQuestion: Question | undefined = filteredQuestions[currentQuestionIndex];

  if (!currentQuestion) {
      return (
        <div className="p-4 md:p-8 flex items-center justify-center h-full">
            <div className="bg-white p-8 rounded-xl shadow-md text-center">
                <p className="text-lg text-gray-700">{text.noQuestionsFound}</p>
            </div>
        </div>
      );
  }

  const progressPercentage = ((currentQuestionIndex + 1) / filteredQuestions.length) * 100;

  return (
    <div className="p-4 md:p-8 flex flex-col h-full">
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-xl font-bold text-gray-800">{subject.name[language]}</h2>
          <span className="text-sm font-semibold text-gray-500">
            {currentQuestionIndex + 1} / {filteredQuestions.length}
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: `${progressPercentage}%` }}></div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-md flex-grow">
        <p className="text-lg md:text-xl font-semibold text-gray-700 mb-6 min-h-[6rem]">{currentQuestion.text}</p>
        <div className="space-y-3">
          {currentQuestion.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleSelectAnswer(index)}
              className={`w-full text-start p-4 border-2 rounded-lg transition-all duration-200 ${
                selectedAnswer === index
                  ? 'bg-blue-100 border-blue-500 ring-2 ring-blue-300'
                  : 'bg-slate-50 border-gray-200 hover:bg-gray-100 hover:border-gray-300'
              }`}
            >
              {option}
            </button>
          ))}
        </div>
         {showError && <p className="text-red-500 mt-4">{text.selectAnswer}</p>}
      </div>

      <div className="mt-6">
        <button
          onClick={handleNext}
          className="w-full bg-blue-500 text-white font-bold py-4 px-6 rounded-lg hover:bg-blue-600 transition-colors duration-300 shadow-lg"
        >
          {currentQuestionIndex === filteredQuestions.length - 1 ? text.finishQuiz : text.nextQuestion}
        </button>
      </div>
    </div>
  );
};