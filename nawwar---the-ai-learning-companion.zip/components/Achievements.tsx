
import React from 'react';
import { Language } from '../types';
import { UI_TEXT, ACHIEVEMENTS_DATA } from '../constants';

interface AchievementsProps {
  language: Language;
  unlockedAchievements: Set<string>;
}

export const Achievements: React.FC<AchievementsProps> = ({ language, unlockedAchievements }) => {
  const text = UI_TEXT[language];

  return (
    <div className="p-4 md:p-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">{text.achievements}</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ACHIEVEMENTS_DATA.map((ach) => {
          const isUnlocked = unlockedAchievements.has(ach.id);
          return (
            <div
              key={ach.id}
              className={`bg-white p-6 rounded-xl shadow-md flex items-center transition-all duration-300 ${
                isUnlocked ? 'border-2 border-blue-500' : 'opacity-60'
              }`}
            >
              <div className={`p-3 rounded-full ${isUnlocked ? 'bg-blue-100' : 'bg-gray-100'}`}>
                 <ach.icon className={`w-8 h-8 ${isUnlocked ? 'text-blue-500' : 'text-gray-400'}`} />
              </div>
              <div className="ms-4 flex-1">
                <h3 className="font-bold text-gray-800">{ach.name[language]}</h3>
                <p className="text-sm text-gray-500">{ach.description[language]}</p>
                {isUnlocked && <p className="text-xs font-bold text-green-600 mt-1">{text.unlocked.toUpperCase()}</p>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
