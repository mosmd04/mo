
import React from 'react';
import { Language } from '../types';
import { UI_TEXT, LEADERBOARD_DATA } from '../constants';

interface LeaderboardProps {
  language: Language;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ language }) => {
  const text = UI_TEXT[language];

  const getMedal = (rank: number) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return rank;
  };
  
  return (
    <div className="p-4 md:p-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">{text.leaderboard}</h1>
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50">
            <tr>
              <th className="p-4 font-semibold text-gray-600">{text.rank}</th>
              <th className="p-4 font-semibold text-gray-600">{text.name}</th>
              <th className="p-4 font-semibold text-gray-600 text-right">{text.points}</th>
            </tr>
          </thead>
          <tbody>
            {LEADERBOARD_DATA.map((user) => (
              <tr 
                key={user.rank}
                className={`border-t ${user.isCurrentUser ? 'bg-blue-50 font-bold' : ''}`}
              >
                <td className="p-4 w-1/6 text-xl">
                  {getMedal(user.rank)}
                </td>
                <td className="p-4">
                  <div className="flex items-center">
                    <img 
                      src={`https://i.pravatar.cc/40?u=${user.name}`} 
                      alt={user.name}
                      className="w-10 h-10 rounded-full mr-4" 
                    />
                    <span>{user.name}</span>
                  </div>
                </td>
                <td className="p-4 text-right font-semibold text-gray-800">{user.points.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
